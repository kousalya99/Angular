import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeline-vertical-left-page',
  templateUrl: './timeline-vertical-left-page.component.html',
  styleUrls: ['./timeline-vertical-left-page.component.scss']
})
export class TimelineVerticalLeftPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
