import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-respondent-linebar',
  templateUrl: './respondent-linebar.component.html',
  styleUrls: ['./respondent-linebar.component.scss']
})
export class RespondentLinebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
