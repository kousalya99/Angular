import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-respondents',
  templateUrl: './respondents.component.html',
  styleUrls: ['./respondents.component.scss']
})
export class RespondentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
