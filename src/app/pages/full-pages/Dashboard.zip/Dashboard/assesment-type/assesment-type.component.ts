

import { Component, ViewChild } from "@angular/core";



@Component({
  selector: 'app-assesment-type',
  templateUrl: './assesment-type.component.html',
  styleUrls: ['./assesment-type.component.scss']
})
export class AssesmentTypeComponent {
  
  
  ngOnInit(): void {
  }
}

