import { Component, OnInit } from '@angular/core';
import { FormsModule,Validators,FormBuilder, FormArray } from '@angular/forms';
import { DataModel } from '../invoice-list/invoice.model';
import { Router,ActivatedRoute } from '@angular/router';
import { InvoicesService } from '../invoices.service';


@Component({
  selector: 'app-invoice-create',
  templateUrl: './invoice-create.component.html',
  styleUrls: ['./invoice-create.component.scss']
})
export class InvoiceCreateComponent implements OnInit {
  items: DataModel[] = [];
  invoiceForm= this.fb.group({
    id:[],
    invoiceNo: [''],
    invoicedate: [''],
    dueDate: [''],
    balanceAmount: [''],
    sellerDetails:[''],
    buyerDetails:[''],
    items: this.fb.array([]),
  });
  listId: number;
 
  constructor(private fb:FormBuilder,private invoiceservice:InvoicesService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
    let id=parseInt(this.route.snapshot.paramMap.get('id'));
    this.listId=id;
    if(id){
      this.getListItemById(id);
      console.log(id)

    }
  }
 
  get itemsFormArray() {
    return this.invoiceForm.get('items') as FormArray;
  }

  addItem() { 
    this.itemsFormArray.push(this.fb.group({
      itemNo: [''],
      productDescription: [''],
      hours: [''],
      totalAmount: [''],
    }));
  }
  savelist(){
    let formlist=this.invoiceForm.value;
    if(this.listId){
      this.putListItem();
    }else{
    this.invoiceservice.savelist(formlist).subscribe(
      (data:DataModel)=>{
        this.invoiceForm.reset();
        this.router.navigate(['pages/list-invoice'])  
      }
    )
    }
  }
  getListItemById(id:number){
    this.invoiceservice.getListItemById(id).subscribe((data:DataModel)=>{
      this.invoiceForm.patchValue(data);
    }) 
  }
  putListItem(){
    const editList=this.invoiceForm.value;
    if(this.listId){
      this.invoiceservice.putListItem(this.listId,editList).subscribe((data)=>{
        this.router.navigate(['pages/list-invoice']);
      })
    }
  }
}
