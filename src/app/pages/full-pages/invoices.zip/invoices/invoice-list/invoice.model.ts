export interface DataModel{
    id:number;
    invoiceNo: string;
    balanceDue: string;
    invoiceDate: string;
    dueReceipt: string;
    sellerDtls: string;
    buyerDtls: string;
    itemNo: string;
    productDescription: string;
    hours: string;
    totalAmount: string;
}